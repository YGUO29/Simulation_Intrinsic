#ifndef _MCEXTREME_LOGISTIC_RAND_H
#define _MCEXTREME_LOGISTIC_RAND_H

#ifdef __cplusplus
extern "C"
#endif
void mesh_10nodetet(tetmesh * mesh,mcconfig *cfg);

#endif
