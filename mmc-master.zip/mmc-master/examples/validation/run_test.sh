#!/bin/sh

time ../../src/bin/mmc -f cube.inp -s cube -n 1e8 -b 0 -F bin -D TP $@
