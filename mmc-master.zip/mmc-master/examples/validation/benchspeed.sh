#!/bin/sh

time ../../src/bin/mmc -f cube.inp -s cube -n 100000 -b 0 -D PT
