#!/bin/sh

# please download & install MCX v0.4.9 or later
# run 3e8 photons
time mcx -A -g 50 -n 3e8 -f box.inp -s box -a 0 -b 0 -G 1
