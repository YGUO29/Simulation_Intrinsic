#!/bin/sh
date 

../../../src/bin/mmc -n 1000000 -f tank_planar.inp -s tank_planar -b 1 -x 1 -U 0 -D TP

date
