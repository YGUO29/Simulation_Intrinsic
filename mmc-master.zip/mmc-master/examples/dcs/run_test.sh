#!/bin/sh

../../src/bin/mmc -s dcs -f dcs.inp -b 1 -m 1 -D P -d 1
