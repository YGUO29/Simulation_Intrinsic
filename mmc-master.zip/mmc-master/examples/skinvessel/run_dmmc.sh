#!/bin/sh

../../src/bin/mmc -f dmmc_skinvessel.json -n 1e8 -F bin $@

