#!/bin/sh

../../src/bin/mmc -f skinvessel.json -n 1e8 -F bin $@

