#!/bin/sh

../../src/bin/mmc -f dmmc_sphshells.json -n 1e8 -F bin $@

