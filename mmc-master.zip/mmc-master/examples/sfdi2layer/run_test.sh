#!/bin/sh

../../src/bin/mmc -n 3000000 -f sfdi.inp -s sfdi -b 0 -k 0 -D TP
