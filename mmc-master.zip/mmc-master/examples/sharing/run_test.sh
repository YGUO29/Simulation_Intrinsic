#!/bin/sh

../../src/bin/mmc -n 1000000 -f sharing.inp -s sharing -b 1 -k 0 -D TP
