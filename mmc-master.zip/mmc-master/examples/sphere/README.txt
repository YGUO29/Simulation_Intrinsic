= Validation of uniform planar source use a spherical domain =

== Introduction ==

In this example, we test a simple widefield source -- uniform planar over a sphere model.
Three corners of the 3D quadrilateral are specified by srcpos, srcpos+srcparam1(0:2), srcpos+srcparam2(0:2).
The original mesh is re-tessellated after adding source nodes in addsource_sphere.m .
