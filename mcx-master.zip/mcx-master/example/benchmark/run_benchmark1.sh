#!/bin/sh

../../bin/mcx -A -f benchmark1.json -b 0 "$@"
