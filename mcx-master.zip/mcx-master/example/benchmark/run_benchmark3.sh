#!/bin/sh

../../bin/mcx -A -f benchmark3.json -b 1 -s benchmark3 "$@"
