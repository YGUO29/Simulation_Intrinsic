#!/bin/sh

../../bin/mcx -f mcxyz_bench.json -e 0.01 -d 0 -D P "$@"
