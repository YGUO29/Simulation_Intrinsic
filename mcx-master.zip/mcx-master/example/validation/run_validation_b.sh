#!/bin/sh
time ../../bin/mcx -A -g 50 -n 1e8 -f validation_b.inp -s semi_infinite_b -a 0 -b 1 -B 0 -U 1
