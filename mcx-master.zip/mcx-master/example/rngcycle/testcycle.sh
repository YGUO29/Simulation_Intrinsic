#!/bin/sh
../../bin/rngcycle 10 64 100000000 1
