#!/bin/sh

../../bin/mcx -f multipattern.json  "$@"

