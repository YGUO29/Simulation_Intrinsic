#!/bin/sh
../../bin/mcx -A -n 1e8 -f USC_19-5_atlas.json -D P  $@
