#!/bin/sh

../../bin/mcx -A -g 10 -n 1e7 -f qtest_widefield.inp -s qtest_widefield -r 1 -a 0 -b 0 -G 1
