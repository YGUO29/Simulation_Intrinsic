#!/bin/sh
../../bin/mcx -L
