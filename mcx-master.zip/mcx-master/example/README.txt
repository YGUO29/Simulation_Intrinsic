= README for examples =

In this folder, you will find a number of examples 
to validate, test, or demonstrate the functionalities 
of MCX.

Please read the README.txt file for each sub-folder
to understand the purpose, procedures to run and 
the interpretation of the results.
