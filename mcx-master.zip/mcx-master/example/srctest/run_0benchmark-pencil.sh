#!/bin/sh

../../bin/mcx -A -f 0benchmark-pencil.json -b 1 -s 0benchmark-pencil "$@"
