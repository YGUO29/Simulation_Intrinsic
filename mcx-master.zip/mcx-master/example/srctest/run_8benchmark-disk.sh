#!/bin/sh

../../bin/mcx -A -f 8benchmark-disk.json -b 1 -s 8benchmark-disk "$@"
