#!/bin/sh

../../bin/mcx -A -f 10benchmark-fourierx2d.json -b 1 -s 10benchmark-fourierx2d "$@"
