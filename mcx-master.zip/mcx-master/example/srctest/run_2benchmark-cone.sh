#!/bin/sh

../../bin/mcx -A -f 2benchmark-cone.json -b 1 -s 2benchmark-cone "$@"
