#!/bin/sh

../../bin/mcx -A -f 7benchmark-arcsine.json -b 1 -s 7benchmark-arcsine "$@"
