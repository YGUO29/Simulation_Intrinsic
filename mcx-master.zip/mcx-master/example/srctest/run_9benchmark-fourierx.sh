#!/bin/sh

../../bin/mcx -A -f 9benchmark-fourierx.json -b 1 -s 9benchmark-fourierx "$@"
