#!/bin/sh

../../bin/mcx -A -f 6benchmark-fourier.json -b 1 -s 6benchmark-fourier "$@"
