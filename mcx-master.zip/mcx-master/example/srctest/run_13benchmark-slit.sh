#!/bin/sh

../../bin/mcx -A -f 13benchmark-slit.json -b 1 -s 13benchmark-slit "$@"
