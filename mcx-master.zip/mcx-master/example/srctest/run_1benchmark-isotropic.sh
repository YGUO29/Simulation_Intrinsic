#!/bin/sh

../../bin/mcx -A -f 1benchmark-isotropic.json -b 1 -s 1benchmark-isotropic "$@"
