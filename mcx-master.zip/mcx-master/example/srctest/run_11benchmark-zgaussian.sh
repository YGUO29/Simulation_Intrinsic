#!/bin/sh

../../bin/mcx -A -f 11benchmark-zgaussian.json -b 1 -s 11benchmark-zgaussian "$@"
