#!/bin/sh

../../bin/mcx -A -f 4benchmark-planar.json -b 1 -s 4benchmark-planar "$@"
