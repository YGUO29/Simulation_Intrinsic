#!/bin/sh
../../bin/mcx -A -n 1e8 -f colin27.json -D P -F nii $@
