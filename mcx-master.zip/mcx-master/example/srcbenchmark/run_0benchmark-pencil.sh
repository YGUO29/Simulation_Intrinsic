#!/bin/sh

../../bin/mcx -A -f 0benchmark-pencil.json -b 1 0benchmark-pencil "$@"
