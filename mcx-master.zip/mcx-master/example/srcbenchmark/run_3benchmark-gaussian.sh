#!/bin/sh

../../bin/mcx -A -f 3benchmark-gaussian.json -b 1 3benchmark-gaussian "$@"
