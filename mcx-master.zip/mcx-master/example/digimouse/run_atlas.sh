#!/bin/sh
../../bin/mcx -A -n 1e8 -f digimouse.json -D P  $@
